import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator, TextInput, Modal } from 'react-native';
import { useOrganization, useOrganizationAnnouncements, useFollowOrganization, usePostAnnouncement } from '../api/organizations';
import { theme } from '../theme';

export default function OrganizationDetailScreen({ route, navigation }: any) {
  const { orgId } = route.params;
  const { data: org, isLoading } = useOrganization(orgId);
  const { data: announcements } = useOrganizationAnnouncements(orgId);
  const followOrg = useFollowOrganization(orgId);
  const postAnnouncement = usePostAnnouncement(orgId);
  const [announceModalVisible, setAnnounceModalVisible] = useState(false);

  if (isLoading || !org) return <ActivityIndicator style={{ marginTop: 60 }} color={theme.colors.indigo} />;

  const isLeader = org.viewerRole === 'leader';

  return (
    <View style={styles.container}>
      <FlatList
        ListHeaderComponent={
          <View style={styles.header}>
            <View style={styles.topRow}>
              <Text style={styles.orgType}>{org.type}</Text>
              {org.verified && <Text style={styles.verifiedBadge}>✓ Verified</Text>}
            </View>
            <Text style={styles.orgName}>{org.name}</Text>
            {org.description && <Text style={styles.orgDescription}>{org.description}</Text>}
            <Text style={styles.orgMeta}>{org.followerCount} followers · {org.groupCount} groups</Text>

            <View style={styles.buttonRow}>
              {!org.isFollowing && (
                <TouchableOpacity style={styles.followButton} onPress={() => followOrg.mutate()}>
                  <Text style={styles.followButtonText}>Follow</Text>
                </TouchableOpacity>
              )}
              {isLeader && (
                <TouchableOpacity style={styles.announceButton} onPress={() => setAnnounceModalVisible(true)}>
                  <Text style={styles.announceButtonText}>+ Announcement</Text>
                </TouchableOpacity>
              )}
            </View>

            {org.groups?.length > 0 && (
              <>
                <Text style={styles.sectionTitle}>Groups</Text>
                {org.groups.map((g: any) => (
                  <TouchableOpacity key={g.id} style={styles.groupRow} onPress={() => navigation.navigate('GroupDetail', { groupId: g.id })}>
                    <Text style={styles.groupName}>{g.name}</Text>
                    <Text style={styles.groupType}>{g.group_type}</Text>
                  </TouchableOpacity>
                ))}
              </>
            )}

            <Text style={styles.sectionTitle}>Announcements</Text>
          </View>
        }
        data={announcements}
        keyExtractor={(item: any) => item.id}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 24 }}
        renderItem={({ item }: any) => (
          <View style={styles.announcementCard}>
            <Text style={styles.announcementTitle}>{item.title}</Text>
            <Text style={styles.announcementBody}>{item.body}</Text>
            <Text style={styles.announcementMeta}>{item.author_name}</Text>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>No announcements yet.</Text>}
      />

      <Modal visible={announceModalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <AnnouncementForm onSubmit={(a) => { postAnnouncement.mutate(a); setAnnounceModalVisible(false); }} onClose={() => setAnnounceModalVisible(false)} />
        </View>
      </Modal>
    </View>
  );
}

function AnnouncementForm({ onSubmit, onClose }: { onSubmit: (a: { title: string; body: string }) => void; onClose: () => void }) {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  return (
    <View style={styles.modalCard}>
      <Text style={styles.modalTitle}>New Announcement</Text>
      <TextInput style={styles.input} placeholder="Title" value={title} onChangeText={setTitle} />
      <TextInput style={[styles.input, styles.textArea]} placeholder="Message" value={body} onChangeText={setBody} multiline />
      <TouchableOpacity style={styles.followButton} onPress={() => title.trim() && body.trim() && onSubmit({ title, body })}>
        <Text style={styles.followButtonText}>Post</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={onClose}><Text style={styles.cancelText}>Cancel</Text></TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.parchment },
  header: { paddingTop: 56, paddingHorizontal: 16, paddingBottom: 8 },
  topRow: { flexDirection: 'row', justifyContent: 'space-between' },
  orgType: { color: theme.colors.mutedText, fontSize: 12, textTransform: 'uppercase' },
  verifiedBadge: { color: '#2E9B5F', fontSize: 12, fontWeight: '700' },
  orgName: { fontSize: 22, fontWeight: '600', color: theme.colors.indigo, marginVertical: 4 },
  orgDescription: { color: theme.colors.text, marginBottom: 8 },
  orgMeta: { color: theme.colors.mutedText, fontSize: 13, marginBottom: 12 },
  buttonRow: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  followButton: { backgroundColor: theme.colors.indigo, borderRadius: 20, paddingHorizontal: 20, paddingVertical: 10 },
  followButtonText: { color: '#fff', fontWeight: '600' },
  announceButton: { backgroundColor: theme.colors.flame, borderRadius: 20, paddingHorizontal: 20, paddingVertical: 10 },
  announceButtonText: { color: '#fff', fontWeight: '600' },
  sectionTitle: { fontSize: 14, fontWeight: '600', color: theme.colors.indigo, marginTop: 12, marginBottom: 8 },
  groupRow: { flexDirection: 'row', justifyContent: 'space-between', backgroundColor: '#fff', borderRadius: 10, padding: 12, marginBottom: 6 },
  groupName: { color: theme.colors.text },
  groupType: { color: theme.colors.mutedText, fontSize: 12, textTransform: 'uppercase' },
  announcementCard: { backgroundColor: '#fff', borderRadius: 12, padding: 14, marginBottom: 10 },
  announcementTitle: { fontWeight: '600', color: theme.colors.text, marginBottom: 4 },
  announcementBody: { color: theme.colors.text, marginBottom: 6 },
  announcementMeta: { color: theme.colors.mutedText, fontSize: 11 },
  empty: { textAlign: 'center', color: theme.colors.mutedText, marginTop: 12 },
  modalOverlay: { flex: 1, backgroundColor: '#00000055', justifyContent: 'flex-end' },
  modalCard: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20 },
  modalTitle: { fontSize: 18, fontWeight: '600', marginBottom: 12, color: theme.colors.indigo },
  input: { borderWidth: 1, borderColor: '#e2e0d5', borderRadius: 10, padding: 12, marginBottom: 10 },
  textArea: { height: 80, textAlignVertical: 'top' },
  cancelText: { textAlign: 'center', color: theme.colors.mutedText, marginTop: 4 },
});
