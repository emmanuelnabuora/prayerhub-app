import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, TextInput, ActivityIndicator } from 'react-native';
import { useAskAssistant, useStudyQuestions, useDevotionalPrompt, useStructurePrayer } from '../api/ai';
import { theme } from '../theme';

type Mode = 'ask' | 'study' | 'devotional' | 'prayer';

// A single-purpose "study & prayer companion" screen — not a general chatbot.
// The disclaimer banner is permanent, not a one-time dismissible modal, per the
// master spec's requirement that generated text is never presented as prophecy
// or divine speech (see apps/api/src/ai/assistant.prompts.ts for the matching
// server-side system prompt).
export default function AssistantScreen() {
  const [mode, setMode] = useState<Mode>('ask');
  const [input, setInput] = useState('');
  const [answer, setAnswer] = useState<string | null>(null);

  const ask = useAskAssistant();
  const studyQuestions = useStudyQuestions();
  const devotionalPrompt = useDevotionalPrompt();
  const structurePrayer = useStructurePrayer();

  const isPending = ask.isPending || studyQuestions.isPending || devotionalPrompt.isPending || structurePrayer.isPending;

  const submit = () => {
    setAnswer(null);
    if (mode === 'ask') ask.mutate({ question: input }, { onSuccess: (r) => setAnswer(r.answer) });
    if (mode === 'study') studyQuestions.mutate({ passage: input }, { onSuccess: (r) => setAnswer(r.answer) });
    if (mode === 'devotional') devotionalPrompt.mutate({ theme: input || undefined }, { onSuccess: (r) => setAnswer(r.answer) });
    if (mode === 'prayer') structurePrayer.mutate({ situation: input }, { onSuccess: (r) => setAnswer(r.answer) });
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingTop: 56, paddingBottom: 40 }}>
      <Text style={styles.title}>PrayerHub Assistant</Text>
      <View style={styles.disclaimer}>
        <Text style={styles.disclaimerText}>
          A study tool, not a prophet — responses are generated, always cite Scripture
          separately from commentary, and are never God's direct word to you. For pastoral
          guidance, talk with a pastor or trusted leader.
        </Text>
      </View>

      <View style={styles.modeRow}>
        {([
          { key: 'ask', label: 'Ask' },
          { key: 'study', label: 'Study Qs' },
          { key: 'devotional', label: 'Devotional' },
          { key: 'prayer', label: 'Structure Prayer' },
        ] as const).map((m) => (
          <TouchableOpacity key={m.key} style={[styles.modeChip, mode === m.key && styles.modeChipActive]} onPress={() => { setMode(m.key); setAnswer(null); }}>
            <Text style={mode === m.key ? styles.modeTextActive : styles.modeText}>{m.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <TextInput
        style={[styles.input, styles.textArea]}
        placeholder={
          mode === 'ask' ? 'Ask about a passage, topic, or word study…' :
          mode === 'study' ? 'A passage, e.g. Romans 8:28-39' :
          mode === 'devotional' ? 'A theme (optional), e.g. gratitude' :
          'What would you like to pray about?'
        }
        value={input}
        onChangeText={setInput}
        multiline
      />
      <TouchableOpacity style={styles.submitButton} onPress={submit} disabled={isPending || (!input.trim() && mode !== 'devotional')}>
        <Text style={styles.submitButtonText}>{isPending ? 'Thinking…' : 'Go'}</Text>
      </TouchableOpacity>

      {isPending && <ActivityIndicator style={{ marginTop: 20 }} color={theme.colors.indigo} />}
      {answer && (
        <View style={styles.answerCard}>
          <Text style={styles.answerText}>{answer}</Text>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.parchment, paddingHorizontal: 16 },
  title: { fontSize: 22, color: theme.colors.indigo, fontWeight: '600', marginBottom: 10 },
  disclaimer: { backgroundColor: '#EFE6D8', borderRadius: 10, padding: 12, marginBottom: 16 },
  disclaimerText: { color: theme.colors.text, fontSize: 12, lineHeight: 18 },
  modeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  modeChip: { borderWidth: 1, borderColor: '#e2e0d5', borderRadius: 16, paddingHorizontal: 12, paddingVertical: 6 },
  modeChipActive: { backgroundColor: theme.colors.indigo, borderColor: theme.colors.indigo },
  modeText: { color: theme.colors.text, fontSize: 13 },
  modeTextActive: { color: '#fff', fontSize: 13 },
  input: { borderWidth: 1, borderColor: '#e2e0d5', borderRadius: 10, padding: 12, backgroundColor: '#fff', marginBottom: 10 },
  textArea: { minHeight: 70, textAlignVertical: 'top' },
  submitButton: { backgroundColor: theme.colors.flame, borderRadius: 12, padding: 14, alignItems: 'center' },
  submitButtonText: { color: '#fff', fontWeight: '600' },
  answerCard: { backgroundColor: '#fff', borderRadius: 14, padding: 16, marginTop: 16 },
  answerText: { color: theme.colors.text, lineHeight: 22 },
});
