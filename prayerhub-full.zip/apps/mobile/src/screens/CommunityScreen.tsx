import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, TextInput, Modal, ActivityIndicator } from 'react-native';
import { useDiscoverGroups, useMyGroups, useCreateGroup, useJoinGroup } from '../api/groups';
import { theme } from '../theme';

export default function CommunityScreen({ navigation }: any) {
  const [tab, setTab] = useState<'mine' | 'discover'>('mine');
  const myGroups = useMyGroups();
  const discover = useDiscoverGroups();
  const joinGroup = useJoinGroup();
  const [modalVisible, setModalVisible] = useState(false);

  const data = tab === 'mine' ? myGroups.data : discover.data;
  const isLoading = tab === 'mine' ? myGroups.isLoading : discover.isLoading;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Community</Text>
        <TouchableOpacity style={styles.newButton} onPress={() => setModalVisible(true)}>
          <Text style={styles.newButtonText}>+ New</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.orgLinkCard} onPress={() => navigation.navigate('Organizations')}>
        <Text style={styles.orgLinkText}>⛪ Churches & Ministries</Text>
      </TouchableOpacity>

      <View style={styles.tabs}>
        <TouchableOpacity style={[styles.tabButton, tab === 'mine' && styles.tabButtonActive]} onPress={() => setTab('mine')}>
          <Text style={tab === 'mine' ? styles.tabTextActive : styles.tabText}>My Groups</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tabButton, tab === 'discover' && styles.tabButtonActive]} onPress={() => setTab('discover')}>
          <Text style={tab === 'discover' ? styles.tabTextActive : styles.tabText}>Discover</Text>
        </TouchableOpacity>
      </View>

      {isLoading ? (
        <ActivityIndicator style={{ marginTop: 40 }} color={theme.colors.indigo} />
      ) : (
        <FlatList
          data={data}
          keyExtractor={(item: any) => item.id}
          contentContainerStyle={{ padding: 16 }}
          renderItem={({ item }: any) => (
            <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('GroupDetail', { groupId: item.id })}>
              <Text style={styles.cardType}>{item.groupType.replace('_', ' ')}</Text>
              <Text style={styles.cardTitle}>{item.name}</Text>
              <Text style={styles.cardMeta}>{item.memberCount} members · {item.visibility}</Text>
              {!item.isMember && (
                <TouchableOpacity style={styles.joinButton} onPress={() => joinGroup.mutate(item.id)}>
                  <Text style={styles.joinButtonText}>
                    {item.visibility === 'public' ? 'Join' : 'Request to Join'}
                  </Text>
                </TouchableOpacity>
              )}
            </TouchableOpacity>
          )}
          ListEmptyComponent={
            <Text style={styles.empty}>
              {tab === 'mine' ? "You haven't joined any groups yet — check Discover." : 'No groups to discover yet.'}
            </Text>
          }
        />
      )}

      <NewGroupModal visible={modalVisible} onClose={() => setModalVisible(false)} onCreated={(id) => navigation.navigate('GroupDetail', { groupId: id })} />
    </View>
  );
}

function NewGroupModal({ visible, onClose, onCreated }: { visible: boolean; onClose: () => void; onCreated: (id: string) => void }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [visibility, setVisibility] = useState<'public' | 'private' | 'invite_only'>('public');
  const createGroup = useCreateGroup();

  const submit = () => {
    if (!name.trim()) return;
    createGroup.mutate(
      { name, description, visibility },
      { onSuccess: (group) => { setName(''); setDescription(''); onClose(); onCreated(group.id); } },
    );
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.modalOverlay}>
        <View style={styles.modalCard}>
          <Text style={styles.modalTitle}>Start a Group</Text>
          <TextInput style={styles.input} placeholder="Group name" value={name} onChangeText={setName} />
          <TextInput style={[styles.input, styles.textArea]} placeholder="Description" value={description} onChangeText={setDescription} multiline />
          <View style={styles.visibilityRow}>
            {(['public', 'private', 'invite_only'] as const).map((v) => (
              <TouchableOpacity key={v} style={[styles.visibilityChip, visibility === v && styles.visibilityChipActive]} onPress={() => setVisibility(v)}>
                <Text style={visibility === v ? styles.visibilityTextActive : styles.visibilityText}>{v.replace('_', ' ')}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <TouchableOpacity style={styles.submitButton} onPress={submit} disabled={createGroup.isPending}>
            <Text style={styles.submitButtonText}>{createGroup.isPending ? 'Creating…' : 'Create Group'}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={onClose}><Text style={styles.cancelText}>Cancel</Text></TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.parchment },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, paddingTop: 56 },
  headerTitle: { fontSize: 24, color: theme.colors.indigo, fontWeight: '600' },
  newButton: { backgroundColor: theme.colors.flame, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
  newButtonText: { color: '#fff', fontWeight: '600' },
  orgLinkCard: { backgroundColor: '#fff', borderRadius: 12, padding: 14, marginHorizontal: 16, marginBottom: 12 },
  orgLinkText: { color: theme.colors.indigo, fontWeight: '600' },
  tabs: { flexDirection: 'row', paddingHorizontal: 16, gap: 8, marginBottom: 8 },
  tabButton: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 16, backgroundColor: '#fff' },
  tabButtonActive: { backgroundColor: theme.colors.indigo },
  tabText: { color: theme.colors.text },
  tabTextActive: { color: '#fff', fontWeight: '600' },
  card: { backgroundColor: '#fff', borderRadius: 14, padding: 16, marginBottom: 12 },
  cardType: { color: theme.colors.mutedText, fontSize: 12, textTransform: 'uppercase' },
  cardTitle: { fontSize: 17, fontWeight: '600', color: theme.colors.text, marginVertical: 4 },
  cardMeta: { color: theme.colors.mutedText, fontSize: 13, marginBottom: 8 },
  joinButton: { alignSelf: 'flex-start', backgroundColor: theme.colors.parchment, borderRadius: 16, paddingHorizontal: 12, paddingVertical: 6 },
  joinButtonText: { color: theme.colors.indigo, fontWeight: '600', fontSize: 12 },
  empty: { textAlign: 'center', color: theme.colors.mutedText, marginTop: 40 },
  modalOverlay: { flex: 1, backgroundColor: '#00000055', justifyContent: 'flex-end' },
  modalCard: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20 },
  modalTitle: { fontSize: 18, fontWeight: '600', marginBottom: 12, color: theme.colors.indigo },
  input: { borderWidth: 1, borderColor: '#e2e0d5', borderRadius: 10, padding: 12, marginBottom: 10 },
  textArea: { height: 70, textAlignVertical: 'top' },
  visibilityRow: { flexDirection: 'row', gap: 8, marginBottom: 16 },
  visibilityChip: { borderWidth: 1, borderColor: '#e2e0d5', borderRadius: 16, paddingHorizontal: 10, paddingVertical: 6 },
  visibilityChipActive: { backgroundColor: theme.colors.indigo, borderColor: theme.colors.indigo },
  visibilityText: { color: theme.colors.text, fontSize: 12 },
  visibilityTextActive: { color: '#fff', fontSize: 12 },
  submitButton: { backgroundColor: theme.colors.indigo, borderRadius: 12, padding: 14, alignItems: 'center', marginBottom: 10 },
  submitButtonText: { color: '#fff', fontWeight: '600' },
  cancelText: { textAlign: 'center', color: theme.colors.mutedText },
});
