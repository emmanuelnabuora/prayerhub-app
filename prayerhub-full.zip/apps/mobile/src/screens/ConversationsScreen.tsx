import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { useConversations } from '../api/messages';
import { theme } from '../theme';

export default function ConversationsScreen({ navigation }: any) {
  const { data: conversations, isLoading } = useConversations();

  return (
    <View style={styles.container}>
      <Text style={styles.headerTitle}>Messages</Text>
      {isLoading ? (
        <ActivityIndicator style={{ marginTop: 40 }} color={theme.colors.indigo} />
      ) : (
        <FlatList
          data={conversations}
          keyExtractor={(item: any) => item.id}
          contentContainerStyle={{ padding: 16 }}
          renderItem={({ item }: any) => (
            <TouchableOpacity style={styles.row} onPress={() => navigation.navigate('Chat', { conversationId: item.id })}>
              <View style={{ flex: 1 }}>
                <Text style={styles.title}>{item.title ?? 'Direct Message'}</Text>
                <Text style={styles.preview} numberOfLines={1}>{item.last_message_body ?? 'Say hello 👋'}</Text>
              </View>
              {Number(item.unread_count) > 0 && (
                <View style={styles.unreadBadge}><Text style={styles.unreadText}>{item.unread_count}</Text></View>
              )}
            </TouchableOpacity>
          )}
          ListEmptyComponent={<Text style={styles.empty}>No conversations yet — message someone from their profile.</Text>}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.parchment, paddingTop: 56 },
  headerTitle: { fontSize: 24, color: theme.colors.indigo, fontWeight: '600', paddingHorizontal: 16, marginBottom: 8 },
  row: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 12, padding: 14, marginBottom: 8 },
  title: { fontWeight: '600', color: theme.colors.text },
  preview: { color: theme.colors.mutedText, fontSize: 13, marginTop: 2 },
  unreadBadge: { backgroundColor: theme.colors.flame, borderRadius: 10, minWidth: 20, height: 20, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5 },
  unreadText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  empty: { textAlign: 'center', color: theme.colors.mutedText, marginTop: 40, paddingHorizontal: 24 },
});
