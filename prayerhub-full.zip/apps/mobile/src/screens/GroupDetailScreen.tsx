import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator, TextInput, Modal } from 'react-native';
import { useGroup, useGroupMembers, useJoinGroup } from '../api/groups';
import { useCreatePrayerRequest } from '../api/prayers';
import { theme } from '../theme';

const DAY_LABELS: Record<string, string> = { MO: 'Mon', TU: 'Tue', WE: 'Wed', TH: 'Thu', FR: 'Fri', SA: 'Sat', SU: 'Sun' };

export default function GroupDetailScreen({ route, navigation }: any) {
  const { groupId } = route.params;
  const { data: group, isLoading } = useGroup(groupId);
  const { data: members } = useGroupMembers(groupId);
  const joinGroup = useJoinGroup();
  const createPrayer = useCreatePrayerRequest();
  const [requestModalVisible, setRequestModalVisible] = useState(false);
  const [requestText, setRequestText] = useState('');

  if (isLoading || !group) return <ActivityIndicator style={{ marginTop: 60 }} color={theme.colors.indigo} />;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.groupType}>{group.groupType.replace('_', ' ')}</Text>
        <Text style={styles.groupName}>{group.name}</Text>
        <Text style={styles.groupDescription}>{group.description}</Text>
        <Text style={styles.groupMeta}>{group.memberCount} members</Text>

        {group.recurringSchedule && (
          <View style={styles.scheduleCard}>
            <Text style={styles.scheduleTitle}>Recurring Meeting</Text>
            <Text style={styles.scheduleText}>
              {group.recurringSchedule.days.map((d: string) => DAY_LABELS[d]).join(', ')} at {group.recurringSchedule.time}
              {group.recurringSchedule.durationMinutes ? ` (${group.recurringSchedule.durationMinutes} min)` : ''}
            </Text>
          </View>
        )}

        {!group.isMember ? (
          <TouchableOpacity style={styles.primaryButton} onPress={() => joinGroup.mutate(groupId)}>
            <Text style={styles.primaryButtonText}>
              {group.visibility === 'public' ? 'Join Group' : 'Request to Join'}
            </Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity style={styles.primaryButton} onPress={() => setRequestModalVisible(true)}>
            <Text style={styles.primaryButtonText}>Share a Prayer Request Here</Text>
          </TouchableOpacity>
        )}
      </View>

      <Text style={styles.sectionTitle}>Members</Text>
      <FlatList
        data={members}
        keyExtractor={(m: any) => m.user_id}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 24 }}
        renderItem={({ item }: any) => (
          <View style={styles.memberRow}>
            <Text style={styles.memberName}>{item.display_name}</Text>
            <Text style={styles.memberRole}>{item.role}</Text>
          </View>
        )}
      />

      <Modal visible={requestModalVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Prayer Request for {group.name}</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="What's on your heart?"
              value={requestText}
              onChangeText={setRequestText}
              multiline
            />
            <TouchableOpacity
              style={styles.primaryButton}
              disabled={!requestText.trim() || createPrayer.isPending}
              onPress={() =>
                createPrayer.mutate(
                  { title: `Prayer request in ${group.name}`, description: requestText, visibility: 'group', groupId },
                  { onSuccess: () => { setRequestText(''); setRequestModalVisible(false); } },
                )
              }
            >
              <Text style={styles.primaryButtonText}>{createPrayer.isPending ? 'Posting…' : 'Post'}</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setRequestModalVisible(false)}>
              <Text style={styles.cancelText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.parchment },
  header: { paddingTop: 56, paddingHorizontal: 16, paddingBottom: 16 },
  groupType: { color: theme.colors.mutedText, fontSize: 12, textTransform: 'uppercase' },
  groupName: { fontSize: 22, fontWeight: '600', color: theme.colors.indigo, marginVertical: 4 },
  groupDescription: { color: theme.colors.text, marginBottom: 8 },
  groupMeta: { color: theme.colors.mutedText, fontSize: 13, marginBottom: 12 },
  scheduleCard: { backgroundColor: '#fff', borderRadius: 12, padding: 12, marginBottom: 12 },
  scheduleTitle: { fontSize: 12, color: theme.colors.mutedText, textTransform: 'uppercase', marginBottom: 4 },
  scheduleText: { color: theme.colors.text, fontWeight: '600' },
  primaryButton: { backgroundColor: theme.colors.indigo, borderRadius: 12, padding: 14, alignItems: 'center' },
  primaryButtonText: { color: '#fff', fontWeight: '600' },
  sectionTitle: { fontSize: 16, fontWeight: '600', color: theme.colors.indigo, paddingHorizontal: 16, marginBottom: 8 },
  memberRow: { flexDirection: 'row', justifyContent: 'space-between', backgroundColor: '#fff', borderRadius: 10, padding: 12, marginBottom: 8 },
  memberName: { color: theme.colors.text },
  memberRole: { color: theme.colors.mutedText, fontSize: 12, textTransform: 'uppercase' },
  modalOverlay: { flex: 1, backgroundColor: '#00000055', justifyContent: 'flex-end' },
  modalCard: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20 },
  modalTitle: { fontSize: 18, fontWeight: '600', marginBottom: 12, color: theme.colors.indigo },
  input: { borderWidth: 1, borderColor: '#e2e0d5', borderRadius: 10, padding: 12, marginBottom: 10 },
  textArea: { height: 90, textAlignVertical: 'top' },
  cancelText: { textAlign: 'center', color: theme.colors.mutedText, marginTop: 4 },
});
