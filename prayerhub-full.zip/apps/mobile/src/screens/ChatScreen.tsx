import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, TextInput, KeyboardAvoidingView, Platform } from 'react-native';
import { useQueryClient } from '@tanstack/react-query';
import { useMessages, useSendMessage, useMarkRead } from '../api/messages';
import { useMessagesSocket } from '../audio/useMessagesSocket';
import { theme } from '../theme';

export default function ChatScreen({ route }: any) {
  const { conversationId } = route.params;
  const { data: messages } = useMessages(conversationId);
  const sendMessage = useSendMessage(conversationId);
  const markRead = useMarkRead(conversationId);
  const queryClient = useQueryClient();
  const [text, setText] = useState('');

  useEffect(() => { markRead.mutate(); }, [conversationId]);

  useMessagesSocket(conversationId, () => {
    queryClient.invalidateQueries({ queryKey: ['conversations', conversationId, 'messages'] });
  });

  const submit = () => {
    if (!text.trim()) return;
    sendMessage.mutate({ type: 'text', body: text }, { onSuccess: () => setText('') });
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <FlatList
        data={messages}
        keyExtractor={(item: any) => item.id}
        contentContainerStyle={{ padding: 16, paddingTop: 56 }}
        renderItem={({ item }: any) => (
          <View style={styles.bubbleRow}>
            <Text style={styles.senderName}>{item.sender.displayName}</Text>
            <View style={styles.bubble}>
              <Text style={styles.bubbleText}>{item.body}</Text>
            </View>
          </View>
        )}
      />
      <View style={styles.composer}>
        <TextInput style={styles.input} placeholder="Message…" value={text} onChangeText={setText} onSubmitEditing={submit} />
        <TouchableOpacity style={styles.sendButton} onPress={submit}>
          <Text style={styles.sendButtonText}>Send</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.parchment },
  bubbleRow: { marginBottom: 12 },
  senderName: { fontSize: 11, color: theme.colors.mutedText, marginBottom: 2 },
  bubble: { backgroundColor: '#fff', borderRadius: 14, padding: 12, alignSelf: 'flex-start', maxWidth: '85%' },
  bubbleText: { color: theme.colors.text },
  composer: { flexDirection: 'row', padding: 12, gap: 8, borderTopWidth: 1, borderTopColor: '#e2e0d5' },
  input: { flex: 1, backgroundColor: '#fff', borderRadius: 20, paddingHorizontal: 16, paddingVertical: 10 },
  sendButton: { backgroundColor: theme.colors.indigo, borderRadius: 20, paddingHorizontal: 16, justifyContent: 'center' },
  sendButtonText: { color: '#fff', fontWeight: '600' },
});
