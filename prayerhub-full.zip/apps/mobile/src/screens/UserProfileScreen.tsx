import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { api } from '../api/client';
import { useFollowUser } from '../api/social';
import { useStartDirectConversation } from '../api/messages';
import { theme } from '../theme';

export default function UserProfileScreen({ route, navigation }: any) {
  const { userId } = route.params;
  const { data: user, isLoading } = useQuery({
    queryKey: ['user', userId],
    queryFn: async () => (await api.get(`/users/${userId}`)).data,
  });
  const followUser = useFollowUser();
  const startConversation = useStartDirectConversation();

  if (isLoading || !user) return <ActivityIndicator style={{ marginTop: 60 }} color={theme.colors.indigo} />;

  return (
    <View style={styles.container}>
      <View style={styles.avatarCircle}><Text style={styles.avatarInitial}>{user.display_name[0]}</Text></View>
      <Text style={styles.name}>{user.display_name}</Text>
      <Text style={styles.username}>@{user.username}</Text>
      {user.bio && <Text style={styles.bio}>{user.bio}</Text>}
      <View style={styles.buttonRow}>
        <TouchableOpacity style={styles.followButton} onPress={() => followUser.mutate(userId)}>
          <Text style={styles.followButtonText}>Follow</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.messageButton}
          onPress={() =>
            startConversation.mutate(userId, {
              onSuccess: (conversation) => navigation.navigate('Chat', { conversationId: conversation.id }),
            })
          }
        >
          <Text style={styles.messageButtonText}>Message</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.parchment, paddingTop: 60, alignItems: 'center' },
  avatarCircle: { width: 80, height: 80, borderRadius: 40, backgroundColor: theme.colors.flame, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  avatarInitial: { color: '#fff', fontSize: 32, fontWeight: '700' },
  name: { fontSize: 20, fontWeight: '600', color: theme.colors.indigo },
  username: { color: theme.colors.mutedText, marginBottom: 12 },
  bio: { color: theme.colors.text, textAlign: 'center', paddingHorizontal: 32, marginBottom: 16 },
  followButton: { backgroundColor: theme.colors.indigo, borderRadius: 20, paddingHorizontal: 24, paddingVertical: 10 },
  followButtonText: { color: '#fff', fontWeight: '600' },
  buttonRow: { flexDirection: 'row', gap: 10 },
  messageButton: { backgroundColor: theme.colors.flame, borderRadius: 20, paddingHorizontal: 24, paddingVertical: 10 },
  messageButtonText: { color: '#fff', fontWeight: '600' },
});
