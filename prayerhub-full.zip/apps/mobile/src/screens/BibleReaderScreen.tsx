import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, TextInput, ActivityIndicator } from 'react-native';
import { useBibleBooks, useBibleChapter, useAddBookmark } from '../api/bible';
import { theme } from '../theme';

// Reachable from anywhere a <ScriptureLink> is tapped (see components/ScriptureLink.tsx)
// or from the Home "Daily Scripture" card. `route.params` optionally pre-selects a
// book/chapter/verse; otherwise defaults to John 3.
export default function BibleReaderScreen({ route }: any) {
  const initial = route?.params ?? {};
  const [bookId, setBookId] = useState(initial.bookId ?? 'JHN');
  const [chapter, setChapter] = useState(initial.chapter ?? 3);
  const [pickerOpen, setPickerOpen] = useState(false);

  const { data: books } = useBibleBooks();
  const { data: passage, isLoading } = useBibleChapter(bookId, chapter);
  const addBookmark = useAddBookmark();

  const bookName = books?.find((b: any) => b.id === bookId)?.name ?? bookId;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.chapterPicker} onPress={() => setPickerOpen((v) => !v)}>
          <Text style={styles.chapterPickerText}>{bookName} {chapter} ▾</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => addBookmark.mutate({
            bookId, chapter, verseStart: 1, referenceLabel: `${bookName} ${chapter}`,
          })}
        >
          <Text style={styles.bookmarkAction}>🔖 Save</Text>
        </TouchableOpacity>
      </View>

      {pickerOpen && (
        <ScrollView horizontal style={styles.bookRow} showsHorizontalScrollIndicator={false}>
          {books?.map((b: any) => (
            <TouchableOpacity
              key={b.id}
              style={[styles.bookChip, b.id === bookId && styles.bookChipActive]}
              onPress={() => { setBookId(b.id); setChapter(1); setPickerOpen(false); }}
            >
              <Text style={b.id === bookId ? styles.bookChipTextActive : styles.bookChipText}>{b.name}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}

      {isLoading ? (
        <ActivityIndicator style={{ marginTop: 40 }} color={theme.colors.indigo} />
      ) : (
        <ScrollView style={styles.passageScroll} contentContainerStyle={{ padding: 20 }}>
          <Text style={styles.passageText}>{passage?.text}</Text>
          {passage?.copyright && <Text style={styles.copyright}>{passage.copyright}</Text>}
        </ScrollView>
      )}

      <View style={styles.chapterNav}>
        <TouchableOpacity onPress={() => setChapter((c: number) => Math.max(1, c - 1))}>
          <Text style={styles.navButton}>‹ Prev</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setChapter((c: number) => c + 1)}>
          <Text style={styles.navButton}>Next ›</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.parchment, paddingTop: 56 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, marginBottom: 8 },
  chapterPicker: {},
  chapterPickerText: { fontSize: 20, fontWeight: '600', color: theme.colors.indigo },
  bookmarkAction: { color: theme.colors.flame, fontWeight: '600' },
  bookRow: { paddingHorizontal: 16, marginBottom: 8, maxHeight: 40 },
  bookChip: { borderWidth: 1, borderColor: '#e2e0d5', borderRadius: 16, paddingHorizontal: 12, paddingVertical: 6, marginRight: 6 },
  bookChipActive: { backgroundColor: theme.colors.indigo, borderColor: theme.colors.indigo },
  bookChipText: { color: theme.colors.text, fontSize: 13 },
  bookChipTextActive: { color: '#fff', fontSize: 13 },
  passageScroll: { flex: 1 },
  passageText: { fontSize: 18, lineHeight: 30, color: theme.colors.text },
  copyright: { marginTop: 16, fontSize: 11, color: theme.colors.mutedText, fontStyle: 'italic' },
  chapterNav: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 24, paddingVertical: 16 },
  navButton: { color: theme.colors.indigo, fontWeight: '600', fontSize: 16 },
});
