import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, TextInput, ActivityIndicator } from 'react-native';
import { useJournal, useCreateJournalEntry, useMarkAnswered, useConvertToTestimony } from '../api/journal';
import { theme } from '../theme';

// Private journal — reachable from the Profile tab. Every entry here belongs only
// to the signed-in user (enforced server-side in JournalService), so there's no
// "visibility" control in this UI at all, unlike the public Pray feed.
export default function JournalScreen() {
  const { data: entries, isLoading } = useJournal();
  const createEntry = useCreateJournalEntry();
  const markAnswered = useMarkAnswered();
  const convertToTestimony = useConvertToTestimony();
  const [body, setBody] = useState('');

  return (
    <View style={styles.container}>
      <Text style={styles.headerTitle}>Prayer Journal</Text>

      <View style={styles.composer}>
        <TextInput
          style={styles.input}
          placeholder="What are you praying about?"
          value={body}
          onChangeText={setBody}
          multiline
        />
        <TouchableOpacity
          style={styles.addButton}
          disabled={!body.trim() || createEntry.isPending}
          onPress={() => createEntry.mutate({ body }, { onSuccess: () => setBody('') })}
        >
          <Text style={styles.addButtonText}>Add Entry</Text>
        </TouchableOpacity>
      </View>

      {isLoading ? (
        <ActivityIndicator style={{ marginTop: 40 }} color={theme.colors.indigo} />
      ) : (
        <FlatList
          data={entries}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ padding: 16 }}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <Text style={styles.statusBadge}>{item.status}</Text>
              <Text style={styles.cardBody}>{item.body}</Text>
              {item.status !== 'answered' ? (
                <TouchableOpacity onPress={() => markAnswered.mutate(item.id)}>
                  <Text style={styles.actionLink}>Mark as answered</Text>
                </TouchableOpacity>
              ) : !item.converted_to_testimony_id ? (
                <TouchableOpacity onPress={() => convertToTestimony.mutate(item.id)}>
                  <Text style={styles.actionLink}>Share as testimony</Text>
                </TouchableOpacity>
              ) : (
                <Text style={styles.sharedText}>Shared as a testimony</Text>
              )}
            </View>
          )}
          ListEmptyComponent={<Text style={styles.empty}>Your journal is empty — start with one line.</Text>}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.parchment, paddingTop: 56 },
  headerTitle: { fontSize: 24, color: theme.colors.indigo, fontWeight: '600', paddingHorizontal: 16, marginBottom: 12 },
  composer: { paddingHorizontal: 16, marginBottom: 8 },
  input: { backgroundColor: '#fff', borderRadius: 10, padding: 12, minHeight: 60, textAlignVertical: 'top' },
  addButton: { backgroundColor: theme.colors.indigo, borderRadius: 10, padding: 10, alignItems: 'center', marginTop: 8 },
  addButtonText: { color: '#fff', fontWeight: '600' },
  card: { backgroundColor: '#fff', borderRadius: 14, padding: 16, marginBottom: 12 },
  statusBadge: { alignSelf: 'flex-start', backgroundColor: theme.colors.parchment, color: theme.colors.indigo, fontSize: 11, fontWeight: '600', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8, marginBottom: 8, textTransform: 'uppercase' },
  cardBody: { color: theme.colors.text, marginBottom: 10 },
  actionLink: { color: theme.colors.flame, fontWeight: '600' },
  sharedText: { color: theme.colors.mutedText, fontStyle: 'italic' },
  empty: { textAlign: 'center', color: theme.colors.mutedText, marginTop: 40 },
});
