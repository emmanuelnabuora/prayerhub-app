import React, { useState } from 'react';
import { View, TextInput, FlatList, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useSearchUsers } from '../api/social';
import { theme } from '../theme';

// Universal discovery starts with people search; group/room/Scripture search
// already exist as their own endpoints (GET /groups, GET /bible/search) and get
// merged into one results view here once those UIs are ready to share a screen —
// documented as a follow-up in docs/11-SPRINT-6.md rather than stubbed with fake
// tabs today.
export default function SearchScreen() {
  const [query, setQuery] = useState('');
  const { data: users } = useSearchUsers(query);
  const navigation = useNavigation<any>();

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Search people…"
        value={query}
        onChangeText={setQuery}
        autoFocus
      />
      <FlatList
        data={users}
        keyExtractor={(item: any) => item.id}
        contentContainerStyle={{ padding: 16 }}
        renderItem={({ item }: any) => (
          <TouchableOpacity style={styles.row} onPress={() => navigation.navigate('UserProfile', { userId: item.id })}>
            <Text style={styles.name}>{item.display_name}</Text>
            <Text style={styles.username}>@{item.username}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.parchment, paddingTop: 56, paddingHorizontal: 16 },
  input: { backgroundColor: '#fff', borderRadius: 10, padding: 12, marginBottom: 8 },
  row: { backgroundColor: '#fff', borderRadius: 10, padding: 12, marginBottom: 8 },
  name: { color: theme.colors.text, fontWeight: '600' },
  username: { color: theme.colors.mutedText, fontSize: 12 },
});
