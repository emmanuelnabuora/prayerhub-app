import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, TextInput, Modal, ActivityIndicator } from 'react-native';
import { useFeed, useCreatePost, useReactToPost } from '../api/social';
import { theme } from '../theme';

// The community feed: text, Scripture, and audio posts, ordered newest-first,
// visibility-filtered server-side (public/followers/group) exactly like the
// prayer feed. "Amen" is intentionally a lightweight reaction, not a like-count
// arms race — see docs/02-ARCHITECTURE.md's note on avoiding addictive engagement.
export default function FeedScreen() {
  const { data: posts, isLoading } = useFeed();
  const react = useReactToPost();
  const [modalVisible, setModalVisible] = useState(false);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Feed</Text>
        <TouchableOpacity style={styles.newButton} onPress={() => setModalVisible(true)}>
          <Text style={styles.newButtonText}>+ Post</Text>
        </TouchableOpacity>
      </View>

      {isLoading ? (
        <ActivityIndicator style={{ marginTop: 40 }} color={theme.colors.indigo} />
      ) : (
        <FlatList
          data={posts}
          keyExtractor={(item: any) => item.id}
          contentContainerStyle={{ padding: 16 }}
          renderItem={({ item }: any) => (
            <View style={styles.card}>
              <Text style={styles.cardAuthor}>{item.author.displayName}</Text>
              {item.type === 'scripture' && <Text style={styles.scriptureRef}>{item.scriptureReference}</Text>}
              {item.body && <Text style={styles.cardBody}>{item.body}</Text>}
              {item.type === 'audio' && item.media && (
                <View style={styles.audioChip}>
                  <Text style={styles.audioChipText}>🎙️ Audio · {item.media.durationSeconds ?? '—'}s</Text>
                </View>
              )}
              <View style={styles.cardFooter}>
                <TouchableOpacity onPress={() => react.mutate({ postId: item.id, type: 'amen' })}>
                  <Text style={styles.reactionButton}>🙌 Amen</Text>
                </TouchableOpacity>
                <Text style={styles.cardMeta}>{item.reactionCount} · {item.commentCount} comments</Text>
              </View>
            </View>
          )}
          ListEmptyComponent={<Text style={styles.empty}>The feed is quiet — be the first to share something.</Text>}
        />
      )}

      <NewPostModal visible={modalVisible} onClose={() => setModalVisible(false)} />
    </View>
  );
}

function NewPostModal({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const [type, setType] = useState<'text' | 'scripture'>('text');
  const [body, setBody] = useState('');
  const [scriptureReference, setScriptureReference] = useState('');
  const createPost = useCreatePost();

  const submit = () => {
    createPost.mutate(
      type === 'scripture'
        ? { type, scriptureReference, body }
        : { type: 'text', body },
      { onSuccess: () => { setBody(''); setScriptureReference(''); onClose(); } },
    );
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.modalOverlay}>
        <View style={styles.modalCard}>
          <Text style={styles.modalTitle}>Share with the Community</Text>
          <View style={styles.typeRow}>
            {(['text', 'scripture'] as const).map((t) => (
              <TouchableOpacity key={t} style={[styles.typeChip, type === t && styles.typeChipActive]} onPress={() => setType(t)}>
                <Text style={type === t ? styles.typeTextActive : styles.typeText}>{t}</Text>
              </TouchableOpacity>
            ))}
            {/* Audio posts use a separate recording flow (device mic → useRequestUpload
                → useConfirmUpload) — omitted from this quick-post modal to keep the
                text/Scripture path fast; see docs/11-SPRINT-6.md for the recorder note. */}
          </View>
          {type === 'scripture' && (
            <TextInput style={styles.input} placeholder="Reference (e.g. John 3:16)" value={scriptureReference} onChangeText={setScriptureReference} />
          )}
          <TextInput
            style={[styles.input, styles.textArea]}
            placeholder={type === 'scripture' ? 'Why this verse encourages you (optional)' : "What's on your heart?"}
            value={body}
            onChangeText={setBody}
            multiline
          />
          <TouchableOpacity style={styles.submitButton} onPress={submit} disabled={createPost.isPending}>
            <Text style={styles.submitButtonText}>{createPost.isPending ? 'Posting…' : 'Post'}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={onClose}><Text style={styles.cancelText}>Cancel</Text></TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.parchment },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, paddingTop: 56 },
  headerTitle: { fontSize: 24, color: theme.colors.indigo, fontWeight: '600' },
  newButton: { backgroundColor: theme.colors.flame, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
  newButtonText: { color: '#fff', fontWeight: '600' },
  card: { backgroundColor: '#fff', borderRadius: 14, padding: 16, marginBottom: 12 },
  cardAuthor: { color: theme.colors.mutedText, fontSize: 12, marginBottom: 4 },
  scriptureRef: { color: theme.colors.flame, fontWeight: '700', marginBottom: 4 },
  cardBody: { color: theme.colors.text, marginBottom: 10 },
  audioChip: { backgroundColor: theme.colors.parchment, borderRadius: 10, padding: 10, marginBottom: 10, alignSelf: 'flex-start' },
  audioChipText: { color: theme.colors.indigo, fontWeight: '600' },
  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  reactionButton: { color: theme.colors.indigo, fontWeight: '600' },
  cardMeta: { color: theme.colors.mutedText, fontSize: 12 },
  empty: { textAlign: 'center', color: theme.colors.mutedText, marginTop: 40 },
  modalOverlay: { flex: 1, backgroundColor: '#00000055', justifyContent: 'flex-end' },
  modalCard: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20 },
  modalTitle: { fontSize: 18, fontWeight: '600', marginBottom: 12, color: theme.colors.indigo },
  typeRow: { flexDirection: 'row', gap: 8, marginBottom: 12 },
  typeChip: { borderWidth: 1, borderColor: '#e2e0d5', borderRadius: 16, paddingHorizontal: 12, paddingVertical: 6 },
  typeChipActive: { backgroundColor: theme.colors.indigo, borderColor: theme.colors.indigo },
  typeText: { color: theme.colors.text },
  typeTextActive: { color: '#fff' },
  input: { borderWidth: 1, borderColor: '#e2e0d5', borderRadius: 10, padding: 12, marginBottom: 10 },
  textArea: { height: 90, textAlignVertical: 'top' },
  submitButton: { backgroundColor: theme.colors.indigo, borderRadius: 12, padding: 14, alignItems: 'center', marginBottom: 10 },
  submitButtonText: { color: '#fff', fontWeight: '600' },
  cancelText: { textAlign: 'center', color: theme.colors.mutedText },
});
