import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { useTestimonies, useReactToTestimony } from '../api/social';
import { theme } from '../theme';

export default function TestimoniesScreen() {
  const { data: testimonies, isLoading } = useTestimonies();
  const react = useReactToTestimony();

  return (
    <View style={styles.container}>
      <Text style={styles.headerTitle}>Testimonies</Text>
      <Text style={styles.headerSubtitle}>Stories of answered prayer from the community</Text>

      {isLoading ? (
        <ActivityIndicator style={{ marginTop: 40 }} color={theme.colors.indigo} />
      ) : (
        <FlatList
          data={testimonies}
          keyExtractor={(item: any) => item.id}
          contentContainerStyle={{ padding: 16 }}
          renderItem={({ item }: any) => (
            <View style={styles.card}>
              <Text style={styles.categoryBadge}>{item.category}</Text>
              <Text style={styles.cardAuthor}>{item.author.displayName}</Text>
              {item.body && <Text style={styles.cardBody}>{item.body}</Text>}
              <TouchableOpacity onPress={() => react.mutate({ testimonyId: item.id, type: 'amen' })}>
                <Text style={styles.reactionButton}>🙌 Amen ({item.reactionCount})</Text>
              </TouchableOpacity>
            </View>
          )}
          ListEmptyComponent={<Text style={styles.empty}>No testimonies shared yet.</Text>}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.parchment, paddingTop: 56 },
  headerTitle: { fontSize: 24, color: theme.colors.indigo, fontWeight: '600', paddingHorizontal: 16 },
  headerSubtitle: { color: theme.colors.mutedText, paddingHorizontal: 16, marginTop: 4 },
  card: { backgroundColor: '#fff', borderRadius: 14, padding: 16, marginBottom: 12 },
  categoryBadge: { alignSelf: 'flex-start', backgroundColor: theme.colors.parchment, color: theme.colors.indigo, fontSize: 11, fontWeight: '600', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8, marginBottom: 8, textTransform: 'uppercase' },
  cardAuthor: { color: theme.colors.mutedText, fontSize: 12, marginBottom: 6 },
  cardBody: { color: theme.colors.text, marginBottom: 10 },
  reactionButton: { color: theme.colors.indigo, fontWeight: '600' },
  empty: { textAlign: 'center', color: theme.colors.mutedText, marginTop: 40 },
});
