import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, TextInput, Modal, ActivityIndicator } from 'react-native';
import { useOrganizations, useCreateOrganization } from '../api/organizations';
import { theme } from '../theme';

export default function OrganizationsScreen({ navigation }: any) {
  const { data: organizations, isLoading } = useOrganizations();
  const [modalVisible, setModalVisible] = useState(false);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Churches & Ministries</Text>
        <TouchableOpacity style={styles.newButton} onPress={() => setModalVisible(true)}>
          <Text style={styles.newButtonText}>+ New</Text>
        </TouchableOpacity>
      </View>

      {isLoading ? (
        <ActivityIndicator style={{ marginTop: 40 }} color={theme.colors.indigo} />
      ) : (
        <FlatList
          data={organizations}
          keyExtractor={(item: any) => item.id}
          contentContainerStyle={{ padding: 16 }}
          renderItem={({ item }: any) => (
            <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('OrganizationDetail', { orgId: item.id })}>
              <View style={styles.cardTop}>
                <Text style={styles.cardType}>{item.type}</Text>
                {item.verified && <Text style={styles.verifiedBadge}>✓ Verified</Text>}
              </View>
              <Text style={styles.cardTitle}>{item.name}</Text>
              <Text style={styles.cardMeta}>{item.followerCount} followers · {item.groupCount} groups</Text>
            </TouchableOpacity>
          )}
          ListEmptyComponent={<Text style={styles.empty}>No churches or ministries listed yet.</Text>}
        />
      )}

      <NewOrgModal visible={modalVisible} onClose={() => setModalVisible(false)} onCreated={(id) => navigation.navigate('OrganizationDetail', { orgId: id })} />
    </View>
  );
}

function NewOrgModal({ visible, onClose, onCreated }: { visible: boolean; onClose: () => void; onCreated: (id: string) => void }) {
  const [name, setName] = useState('');
  const [type, setType] = useState<'church' | 'ministry'>('church');
  const createOrg = useCreateOrganization();

  const submit = () => {
    if (!name.trim()) return;
    const slug = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    createOrg.mutate(
      { name, slug, type },
      { onSuccess: (org) => { setName(''); onClose(); onCreated(org.id); } },
    );
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.modalOverlay}>
        <View style={styles.modalCard}>
          <Text style={styles.modalTitle}>Register a Church or Ministry</Text>
          <TextInput style={styles.input} placeholder="Name" value={name} onChangeText={setName} />
          <View style={styles.typeRow}>
            {(['church', 'ministry'] as const).map((t) => (
              <TouchableOpacity key={t} style={[styles.typeChip, type === t && styles.typeChipActive]} onPress={() => setType(t)}>
                <Text style={type === t ? styles.typeTextActive : styles.typeText}>{t}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <Text style={styles.hint}>New organizations start unverified — a platform admin reviews and verifies them.</Text>
          <TouchableOpacity style={styles.submitButton} onPress={submit} disabled={createOrg.isPending}>
            <Text style={styles.submitButtonText}>{createOrg.isPending ? 'Creating…' : 'Register'}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={onClose}><Text style={styles.cancelText}>Cancel</Text></TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.parchment },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, paddingTop: 56 },
  headerTitle: { fontSize: 20, color: theme.colors.indigo, fontWeight: '600', flex: 1 },
  newButton: { backgroundColor: theme.colors.flame, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
  newButtonText: { color: '#fff', fontWeight: '600' },
  card: { backgroundColor: '#fff', borderRadius: 14, padding: 16, marginBottom: 12 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between' },
  cardType: { color: theme.colors.mutedText, fontSize: 12, textTransform: 'uppercase' },
  verifiedBadge: { color: '#2E9B5F', fontSize: 12, fontWeight: '700' },
  cardTitle: { fontSize: 17, fontWeight: '600', color: theme.colors.text, marginVertical: 4 },
  cardMeta: { color: theme.colors.mutedText, fontSize: 13 },
  empty: { textAlign: 'center', color: theme.colors.mutedText, marginTop: 40 },
  modalOverlay: { flex: 1, backgroundColor: '#00000055', justifyContent: 'flex-end' },
  modalCard: { backgroundColor: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 20 },
  modalTitle: { fontSize: 18, fontWeight: '600', marginBottom: 12, color: theme.colors.indigo },
  input: { borderWidth: 1, borderColor: '#e2e0d5', borderRadius: 10, padding: 12, marginBottom: 10 },
  typeRow: { flexDirection: 'row', gap: 8, marginBottom: 10 },
  typeChip: { borderWidth: 1, borderColor: '#e2e0d5', borderRadius: 16, paddingHorizontal: 12, paddingVertical: 6 },
  typeChipActive: { backgroundColor: theme.colors.indigo, borderColor: theme.colors.indigo },
  typeText: { color: theme.colors.text },
  typeTextActive: { color: '#fff' },
  hint: { color: theme.colors.mutedText, fontSize: 12, marginBottom: 14 },
  submitButton: { backgroundColor: theme.colors.indigo, borderRadius: 12, padding: 14, alignItems: 'center', marginBottom: 10 },
  submitButtonText: { color: '#fff', fontWeight: '600' },
  cancelText: { textAlign: 'center', color: theme.colors.mutedText },
});
