import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { theme } from '../theme';

export default function ProfileScreen({ navigation }: any) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Profile</Text>
      <TouchableOpacity style={styles.row} onPress={() => navigation.navigate('Journal')}>
        <Text style={styles.rowText}>📓 My Prayer Journal</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.row} onPress={() => navigation.navigate('Conversations')}>
        <Text style={styles.rowText}>💬 Messages</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: theme.colors.parchment, paddingTop: 56, paddingHorizontal: 16 },
  title: { fontSize: 24, color: theme.colors.indigo, fontWeight: '600', marginBottom: 20 },
  row: { backgroundColor: '#fff', borderRadius: 12, padding: 16 },
  rowText: { fontSize: 16, color: theme.colors.text },
});
